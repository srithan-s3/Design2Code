// This script is injected into Pinterest pages.
// It listens for messages from the popup to apply color filters.

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "apply_filter") {
    document.documentElement.style.filter = request.filter;
    sendResponse({ status: "Filter applied" });
  } else if (request.action === "reset_filter") {
    document.documentElement.style.filter = "none";
    sendResponse({ status: "Filter reset" });
  }
});
